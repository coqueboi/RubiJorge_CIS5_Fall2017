
/* 
 * File:   main.cpp
 * Author: Jorge Rubi
 * Created on September 15, 2017, 10:11 PM
 * Purpose: 
 */
//System Libraries
#include <iostream> //I/O Stream Library

using namespace std; // The standard name-space for system libraries 

//User Libraries 

//Global constants - Physics/Math/Conversions only

//Functions Prototypes 

//Execution Begins Here!

int main(int argc, char** argv) {
    //Variable Declaration
    short a,b,total;
    
    //Variable Initialization
    a = 50;
    b = 100;
    
    total = a + b;
    
    //Process Mapping - Inputs to Outputs 
    
    //Re-Display Inputs and write the Outputs
   
    //Exit function main, end of program
    
    return 0;
}

